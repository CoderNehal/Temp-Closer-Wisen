from django.apps import AppConfig


class DmProConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dm_pro'
