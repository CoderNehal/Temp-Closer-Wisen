// src/HomePage.js
import React from 'react';
import './Home.css'; // Import your CSS file for styling

function HomePage() {
  return (
    <div className="container mt-5">
      <h1>NAME : SAURABH SANTOSH PATIL !!</h1>
      <h1>PRN : 2020BTECS00031 !!</h1>
      <h1>SUBJECT : DATA MINING LAB !!</h1>
      <h1>PROJECT : DATA MINING TOOLS IMPLEMENTATION !!</h1>



    </div>
  );
}

export default HomePage;
